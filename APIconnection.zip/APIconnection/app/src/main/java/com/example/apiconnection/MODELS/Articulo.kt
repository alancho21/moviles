package com.example.apiconnection.MODELS

data class Articulo(
    val id: Int,
    val titulo: String,
    val contenido: String
)