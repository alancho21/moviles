package com.example.apiconnection.MODELS

data class ArticulosResponse(
    val data: List<Articulo>
)
