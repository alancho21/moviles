package com.example.apiconnection.Network

import com.example.apiconnection.MODELS.ArticulosResponse
import retrofit2.http.GET

interface ApiService {
    @GET("api/articulos")
    suspend fun getArticulos(): ArticulosResponse
}
