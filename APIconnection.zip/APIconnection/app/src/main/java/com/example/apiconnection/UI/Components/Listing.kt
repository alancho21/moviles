package com.example.apiconnection.UI.Components

import com.example.apiconnection.MODELS.Articulo
import com.example.apiconnection.Network.RetrofitClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.random.Random
import android.util.Log

@ExperimentalMaterialApi
@Composable
fun Listing() {
    val listState = rememberLazyListState()
    var articulos by remember { mutableStateOf<List<Articulo>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try {
            val response = RetrofitClient.api.getArticulos()
            Log.d("API", "Artículos recibidos: ${response.data}")
            articulos = response.data
            isLoading = false
        } catch (e: Exception) {
            Log.e("API", "Error cargando artículos: ${e.message}")
            errorMessage = e.message
            isLoading = false
        }
    }



    when {
        isLoading -> {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("Cargando artículos...", color = Color.Black)
            }
        }
        errorMessage != null -> {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("Error: $errorMessage", color = Color.Red)
            }
        }
        else -> {
            if (articulos.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No se encontraron artículos", color = Color.Black)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.White)
                        .padding(vertical = 4.dp),
                    state = listState
                ) {
                    items(articulos) { articulo ->
                        ArticuloCard(articulo)
                    }
                }
            }
        }
    }
}

@Composable
fun ArticuloCard(articulo: Articulo) {
    val backgroundColor = generateRandomColor()

    Card(
        backgroundColor = backgroundColor,
        modifier = Modifier
            .padding(vertical = 8.dp, horizontal = 12.dp)
            .fillMaxWidth()
            .height(150.dp),
        elevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
            ) {
                Text(text = articulo.titulo, style = MaterialTheme.typography.h6, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = articulo.contenido, style = MaterialTheme.typography.body2, color = Color.White)
            }
        }
    }
}

fun generateRandomColor(): Color {
    val random = Random.Default
    val red = random.nextInt(100, 256)
    val green = random.nextInt(100, 256)
    val blue = random.nextInt(100, 256)
    return Color(red, green, blue)
}
